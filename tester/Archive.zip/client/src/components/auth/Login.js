import React, { useState } from "react";
import { createMuiTheme, makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import Lock from "@material-ui/icons/LockOutlined";
import TextField from "@material-ui/core/TextField";
import { jssPreset, StylesProvider, ThemeProvider } from "@material-ui/styles";
import { create } from "jss";
import rtl from "jss-rtl";
import "./Login.css";
import { login } from "../../actions/auth";
import { connect } from "react-redux";
import Alert from "../../components/layout/Alert";

//Styles
const useStyles = makeStyles(() => ({
  card: {
    display: "flex",
    height: 500,
    width: 500,
    alignItems: "center",
    flexDirection: "column"
  },
  lockIcon: {
    backgroundColor: "lightBlue",
    borderRadius: "100%",
    color: "#fff",
    padding: 5,
    alignSelf: "center"
  },
  iconHolder: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "flex-end",
    flexDirection: "column",
    padding: 30
  },
  root: {
    display: "flex",
    width: "100vw",
    height: "100vh",
    justifyContent: "center",
    alignItems: "center"
  },
  submitButton: {
    width: 400,
    marginRight: 25,
    marginLeft: 25,
    background: "#0066ff",
    height: 50,
    border: 0,
    borderRadius: 20,
    color: "#0208c0",
    fontWeight: "bold",
    fontSize: 18,
    boxShadow: "2px 2px 5px #b9b9b9"
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: " center",
    justifyContent: "space-around",
    height: 400,
    width: 500,
    paddingRight: 30,
    paddingLeft: 30
  },
  inputs: {
    display: "flex",
    width: 400,
    height: 150,
    flexDirection: "column"
  }
}));

//Get browserLanguage
const language = navigator.language;

//Modify MaterialUi for rtl
const theme = createMuiTheme({
  direction: language === "he" ? "rtl" : "ltr"
});

//Modify MaterialUi for rtl
const jss = create({ plugins: [...jssPreset().plugins, rtl()] });

const Login = ({ isAuthenticated, login }) => {
  const classes = useStyles();

  const [data, setData] = useState({
    name: "",
    password: ""
  });

  const { name, password } = data;

  const onChange = e => setData({ ...data, [e.target.name]: e.target.value });

  const onSubmit = e => {
    e.preventDefault();
    login(name, password);
  };

  return (
    <StylesProvider jss={jss}>
      <ThemeProvider theme={theme}>
        <Alert />
        <div className={classes.root}>
          <Card className={`${classes.card} card`}>
            <div className={`${classes.iconHolder} iconHolder`}>
              <Lock fontSize="large" className={classes.lockIcon} />
              <h1>
                {language === "he"
                  ? "אידאה מערכות מידע"
                  : "Idea Information System"}
              </h1>
            </div>
            <form
              className={`${classes.form} form`}
              onSubmit={e => onSubmit(e)}
            >
              <div
                className={`${classes.inputs} inputs`}
                dir={language === "he" ? "rtl" : "ltr"}
              >
                <TextField
                  label={language === "he" ? "שם משתמש" : "User Name "}
                  placeholder={language === "he" ? "שם משתמש" : "User Name "}
                  name={"name"}
                  value={name}
                  onChange={e => onChange(e)}
                  required={true} //Client Side validation
                />
                <TextField
                  label={language === "he" ? "סיסמה" : "Password "}
                  placeholder={language === "he" ? "סיסמה" : "Password "}
                  name={"password"}
                  type={"password"}
                  value={password}
                  onChange={e => onChange(e)}
                  required={true} //Client Side validation
                />
              </div>
              <input
                type="submit"
                value={language === "he" ? "כניסה" : "LOGIN"}
                className={`${classes.submitButton} submitButton`}
              />
            </form>
          </Card>
        </div>
      </ThemeProvider>
    </StylesProvider>
  );
};

const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated
});

export default connect(
  mapStateToProps,
  { login }
)(Login);
