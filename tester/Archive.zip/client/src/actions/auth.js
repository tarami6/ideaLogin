import axios from "axios";
import { setAlert } from "./alert";

import { LOGIN_FAIL, LOGIN_SUCCESS } from "./types";

// Login user
export const login = (name, password) => async dispatch => {
  const config = {
    headers: {
      "Content-Type": "application/json"
    }
  };

  const body = JSON.stringify({ name, password });

  try {
    const res = await axios.post("/api/auth", body, config);
    dispatch({
      type: LOGIN_SUCCESS,
      payload: res.data
    });
    dispatch(setAlert("Logged in", "success"));
  } catch (e) {
    const errors = e.response.data.errors;
    if (errors) {
      errors.forEach(error => {
        dispatch(setAlert(error.msg, "danger"));
      });
    }
    dispatch({
      type: LOGIN_FAIL
    });
  }
};
